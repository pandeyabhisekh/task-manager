from django.apps import AppConfig


class NotezyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'notezyapp'
