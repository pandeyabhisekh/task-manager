import importlib
from django.contrib import admin

from .models import note
# Register your models here.
admin.site.register(note)