# notezy
A simple note taking app using Django
